package pacote2;

public class Pessoa {
    
    public void saudar(){
        System.out.println("Olá, aluno de Java.");
    }
}
