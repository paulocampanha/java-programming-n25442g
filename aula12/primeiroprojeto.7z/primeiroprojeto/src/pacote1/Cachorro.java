package pacote1;

public class Cachorro {
    
    public void latir(){
        System.out.println("AuAu!");
    }
}
