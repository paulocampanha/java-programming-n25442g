import pacote1.Cachorro;
import pacote2.Pessoa;

public class App {
    public static void main(String[] args) throws Exception {
        
        Cachorro cachorro = new Cachorro();
        Pessoa pessoa = new Pessoa();

        cachorro.latir();
        pessoa.saudar();

    }
}
